﻿using System;
using System.IO;
using Hei.Captcha;

namespace generate_captcha
{
    class Program
    {
        static void Main(string[] args)
        {
            var helper = new SecurityCodeHelper();
            var iterations = 2;

            // 创建 output1000 目录，如果不存在
            Directory.CreateDirectory("output10000");

            for (var x = 0; x < iterations; ++x)
            {
                var code = helper.GetRandomEnDigitalText(4);
                var bytes = helper.GetEnDigitalCodeByte(code);

                // 使用验证码文本作为文件名
                var filePath = $"output1000/{code}.png";
                
                // 检查是否已存在同名文件，避免重复
                if (File.Exists(filePath))
                {
                    Console.WriteLine($"File {code}.png already exists, skipping...");
                    continue;
                }

                File.WriteAllBytes(filePath, bytes);

                if (x % 100 == 0)
                    Console.WriteLine($"{x}/{iterations}");
            }
        }
    }
}
